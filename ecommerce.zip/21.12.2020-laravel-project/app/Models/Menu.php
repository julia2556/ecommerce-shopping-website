<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;
use DB;   

class Menu extends Model
{
   protected $primaryKey = 'menu_row_id';  
}
