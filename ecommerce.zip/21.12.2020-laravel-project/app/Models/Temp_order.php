<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Temp_order extends Model
{
     protected $primaryKey = 'temp_order_row_id';

}
