<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;   

class Category extends Model
{
   protected $primaryKey = 'category_row_id';  
}
