<template>
<div> &nbsp;</div>
</template>

<script>
    export default {
        mounted() {
            console.log('example componenet mounted.')
        }
    }
</script>
